window.addEventListener("scroll", function () { 
  let navScroll= document.getElementById("nav")
  navScroll.classList.toggle("fixed", window.scrollY > 10);
})